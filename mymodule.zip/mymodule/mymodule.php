<?php
if (!defined('_PS_VERSION_'))
{
  exit;
}

class MyModule extends Module
{
    public function __construct()
    {
    $this->name = 'mymodule';
    $this->tab = 'front_office_features';
    $this->version = '1.0.0';
    $this->author = 'Mykolas';
    $this->need_instance = 0;
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    $this->bootstrap = true;

    parent::__construct();

    $this->displayName = $this->l('My module');
    $this->description = $this->l('Sample test module.');

    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

    if (!Configuration::get('MYMODULE_NAME'))
      $this->warning = $this->l('No name provided');
    }
    
    public function install()
    {
      if (Shop::isFeatureActive())
        Shop::setContext(Shop::CONTEXT_ALL);

      if (!parent::install() ||
        !$this->registerHook('displayTop') ||
        !$this->registerHook('header') ||
        !Configuration::updateValue('MYMODULE_NAME', 'my friend') ||
        !Configuration::updateValue('MYMODULE_TEXT', 'please write something') ||
        !Configuration::updateValue('MYMODULE_URL', 'please enter the link')
      )
        return false;

      return true;
    }
    
    public function uninstall()
    {
      if (!parent::uninstall() ||
        !Configuration::deleteByName('MYMODULE_NAME') ||
        !Configuration::deleteByName('MYMODULE_TEXT') ||
        !Configuration::deleteByName('MYMODULE_URL')
      )
        return false;

      return true;
    }
    
    public function getContent()
    {
        $output = null;

        if (Tools::isSubmit('submit'.$this->name))
        {
            $my_module_name = strval(Tools::getValue('MYMODULE_NAME'));
            $my_module_message = strval(Tools::getValue('MYMODULE_TEXT'));
            $my_module_url = strval(Tools::getValue('MYMODULE_URL'));
            Configuration::updateValue('MYMODULE_TEXT', $my_module_message);
            Configuration::updateValue('MYMODULE_URL', $my_module_url);
            if (!$my_module_name
              || empty($my_module_name)
              || !Validate::isGenericName($my_module_name))
                $output .= $this->displayError($this->l('Invalid Configuration value'));
            else
            {
                Configuration::updateValue('MYMODULE_NAME', $my_module_name);
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }
        
        return $output.$this->displayForm();
    }
    
    public function displayForm()
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Settings'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Please enter your name:'),
                    'name' => 'MYMODULE_NAME',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Please enter your message:'),
                    'name' => 'MYMODULE_TEXT',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Please enter your url:'),
                    'name' => 'MYMODULE_URL',
                    'size' => 20,
                    'required' => true
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper = new HelperForm();

        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        $helper->title = $this->displayName;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submit'.$this->name;
        $helper->toolbar_btn = array(
            'save' =>
            array(
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
                '&token='.Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' => array(
                'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            )
        );

        $helper->fields_value['MYMODULE_NAME'] = Configuration::get('MYMODULE_NAME');
        $helper->fields_value['MYMODULE_TEXT'] = Configuration::get('MYMODULE_TEXT');
        $helper->fields_value['MYMODULE_URL'] = Configuration::get('MYMODULE_URL');

        return $helper->generateForm($fields_form);
    }
    
    public function hookDisplayTop($params)
    {
      $this->context->smarty->assign(
          array(
              'my_module_name' => Configuration::get('MYMODULE_NAME'),
              'my_module_link' => $this->context->link->getModuleLink('mymodule', 'display'),
              'my_module_message' => Configuration::get('MYMODULE_TEXT'),
              'my_module_url' => Configuration::get('MYMODULE_URL')
          )
      );
      return $this->display(__FILE__, 'mymodule.tpl');
    }

    public function hookDisplayHeader()
    {
      $this->context->controller->addCSS($this->_path.'css/mymodule.css', 'all');
    }
    
}